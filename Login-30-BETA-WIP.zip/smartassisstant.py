
replit.clear()
SAcheck = 1
while SAcheck == 1:
print ("")
cprint ("~~Smart Assisstant~~", 'yellow')
print ("")
SAin = input("Enter Command: ")
SAin = SAin.lower()
if SAin == 'cancel' or SAin == 'quit' or SAin == 'bye' or SAin == 'goodbye' or SAin == 'stop' or SAin == 'end' or SAin == 'close':
  cprint ("Closing", 'yellow')
  time.sleep(0.6)
  SAcheck = 2
elif SAin == 'pick a number' or SAin == 'pick a random number' or SAin == 'pick random number' or SAin == 'choose a random number' or SAin == 'chose a random number' or SAin == 'chose a number' or SAin == 'choose a number' or SAin == 'choose a random number':
  cprint ("Okay, what range?", "yellow")
  sm3 = int(input("Enter the minimum number:  "))
  sm4 = int(input("Enter the maximum number:  "))
  srand = random.randint(sm3, sm4)
  cprint ("I choose: ", "yellow")
  cprint (srand, "yellow")
  time.sleep(0.5)