import replit
from functools import reduce
import numpy as np
from os import sys

results = []
n = 1

while True:
  replit.clear()
  print ("")
  print ("~~HOME~~")
  print ("1. Addition")
  print ("2. Subtraction")
  print ("3. Multiplication")
  print ("4. Division")
  print ("5. Square")
  print ("6. Square Root")
  print ("7. View Previous Results")
  print ("8. Quit Calculator")
  print ("SELECT FUNCTION")
  q1 = input("--> ")
  if q1 == '1':
    replit.clear()
    print ("")
    a1 = int(input("Enter Amount Of Digits: "))
    addition = []
    for i in range (0, a1):
      replit.clear()
      print ("")
      print ("Enter Digit", n)
      a2 = float(input("Enter Digit: "))
      addition.append(a2)
      n = n + 1
    ans_A = sum(addition)
    results.append(ans_A)
    replit.clear()
    print ("")
    print ("ANSWER = ", ans_A)
    print ("")
    n = 1
    a3 = input("Press [ENTER] To Exit")
  elif q1 == '2':
    replit.clear()
    print ("")
    s1 = int(input("Enter Amount Of Digits: "))
    subtraction = []
    for i in range (0, s1):
      replit.clear()
      print ("")
      print ("Enter Digit", n)
      s2 = float(input("Enter Digit: "))
      subtraction.append(s2)
      n = n + 1
    ans_S = subtraction[0] - sum(subtraction[1:])
    results.append(ans_S)
    replit.clear()
    print ("")
    print ("ANSWER = ", ans_S)
    print ("")
    n = 1
    s3 = input("Press [ENTER] To Exit")
  elif q1 == '3':
    replit.clear()
    print ("")
    m1 = int(input("Enter Amount Of Digits: "))
    multiplication = []
    for i in range (0, m1):
      replit.clear()
      print ("")
      print ("Enter Digit", n)
      m2 = float(input("Enter Digit: "))
      multiplication.append(m2)
      n = n + 1
    ans_M = reduce(lambda x, y: x*y, (multiplication))
    results.append(ans_M)
    replit.clear()
    print ("")
    print ("ANSWER = ", ans_M)
    print ("")
    n = 1
    m3 = input("Press [ENTER] To Exit")
  elif q1 == '4':
    replit.clear()
    print ("")
    d1 = float(input("Enter First Digit: "))
    d2 = float(input("Enter Second Digit: "))
    ans_D = (d1 / d2)
    results.append(ans_D)
    replit.clear()
    print ("")
    print ("ANSWER = ", ans_D)
    print ("")
    d3 = input("Press [ENTER] To Exit")
  elif q1 == '5':
    replit.clear()
    print ("")
    sq1 = float(input("Enter Digit: "))
    ans_SQ = (sq1 * sq1)
    results.append(ans_SQ)
    replit.clear()
    print ("")
    print (ans_SQ)
    sq2 = input("Press [ENTER] To EXIT")
  elif q1 == '6':
    replit.clear()
    print ("")
    sqr = float(input("Enter Digit: "))
    ans_SQR = sqr**(.5)
    results.append(ans_SQR)
    replit.clear()
    print ("")
    print ("ANSWER = ", ans_SQR)
    print ("")
    sqr2 = input("Press [ENTER] To Exit")
  elif q1 == '7':
    replit.clear()
    answers = len(results)
    print ("")
    print (answers, "Results Found")
    print ("")
    if answers > 0:
      print ("~~MENU~~")
      print ("1. View All Results")
      print ("2. Exit")
      print ("SELECT FUNCTION")
      q2 = input("--> ")
      if q2 == '1':
        replit.clear()
        print ("")
        print (results)
        print ("")
        q3 = input("Press [ENTER] To Exit")
      elif q2 == '2':
        replit.clear()
  elif q1 == '8':
    replit.clear()
    print ("")
    q4 = input("Press [ENTER] To Quit Calculator")
    replit.clear()
    break
  else:
    replit.clear()
    print ("")
    print ("Invalid Input")
    print ("")
    q7 = input("Press [ENTER] To Exit")