#imports
import time
import sys
import replit
from termcolor import cprint
import random
import datetime
import getpass
from functools import reduce
import numpy as np
import uuid
from termcolor import colored
import socket
import pyspeedtest


#Sub-Programmes
status = False
Echeck = 0
Hcheck = 1
def get_Host_name_IP(): 
    try: 
        host_name = socket.gethostname() 
        host_ip = socket.gethostbyname(host_name) 
        print("Hostname:     ",host_name) 
        print("IP:           ",host_ip) 
    except: 
        print("Unable to get Hostname and IP") 
def newdetails():
  replit.clear()
  print ("")
  Ousername = input(colored("Enter Old Username: ", 'yellow'))
  Opassword = input(colored("Enter Old Password: ", 'yellow'))
  precheck = Ousername + Opassword
  precheck = ' '.join(format(ord(x), 'b') for x in precheck)
  try:
    file = open("code.txt", "r")
    precheck2 = file.read()
    if precheck == precheck2:
      file.close()
      replit.clear()
      print ("")
      Nusername = input(colored("Enter New Username: ", 'yellow'))
      Npassword = input(colored("Enter New Password: ", 'yellow'))
      RNpassword = input(colored("Re-enter New Password: ", 'yellow'))
      if RNpassword == Npassword:
        if Npassword == Opassword or RNpassword == Opassword:
          replit.clear()
          print("")
          cprint ("Your New Password Cannot Be The Same As Your Old Password")
        else:
          Ndetails = Nusername + Npassword
          file = open("code.txt", "w")
          Ndetails = ' '.join(format(ord(x), 'b') for x in Ndetails)
          file.write(Ndetails)
          file.close
          file = open("code.txt", "r")
          acheck = file.read()
          if acheck == Ndetails:
            print ("")
            print ("Details Successfully Updated")
          else:
            print ("")
            cprint ("Error: Unable to update details", 'red')
      else:
        print ("")
        cprint ("Passwords do not match", 'yellow')
    else:
      print ("")
      cprint ("Incorrect Credentials", 'yellow')
  except:
    cprint ("Unable to open user credentials file", 'yellow')





#Home
while status == False:
  replit.clear()
  print ("")
  if Echeck >= 3:
    cprint ("Account Locked", 'red')
    print ("")
    exit = input("Press [ENTER] To Quit")
    replit.clear()
    status = True
  else:
    username = input("Username: ")
    if username == 'quit' or username == 'shut down':
      replit.clear()
      print ("")
      cprint ("Shutting Down", 'red')
      time.sleep(0.5)
      replit.clear()
      print ("")
      cprint ("Shutting Down.", 'red')
      time.sleep(0.5)
      replit.clear()
      print ("")
      cprint ("Shutting Down..", 'red')
      time.sleep(0.5)
      replit.clear()
      print ("")
      cprint ("Shutting Down...", 'red')
      time.sleep(0.7)
      replit.clear()
      status = True
    else:
      password = input("Password: ")
      login = username + password
      entry = ' '.join(format(ord(x), 'b') for x in login)
      
      try:
        file = open("code.txt", "r")
        entry2 = file.read()
        if entry == entry2:
          replit.clear()
          print ("")
          cprint ("Access Verified", 'green',)
          time.sleep(1.7)
          replit.clear()

          #Home Menu
          while Hcheck == 1:
            replit.clear()
            print ("")
            cprint ("~~HOME~~", 'red')
            cprint ("1. Smart Assisstant", 'cyan')
            cprint ("2. Calculator", 'cyan')
            cprint ("3. File Tool", 'cyan')
            cprint ("4. Settings", 'cyan')
            cprint ("5. Log Out", 'green')
            cprint ("6. Shut Down", 'green') 
            Fselect = input("-->  ")


            #Smart Assistant
            if Fselect == '1':
              replit.clear()
              import smartassisstant
              exec('smartassisstant.py')


            elif Fselect == '2':
              replit.clear()
              print ("")
              
        
        
        else:
          replit.clear()
          print ("")
          cprint ("Access Denied", 'red')
          time.sleep(2)
          replit.clear()
          Echeck = Echeck + 1
      

      
      except:
          replit.clear()
          print ("")
          cprint("ERROR: Password File Not Found", "red")
          print ("")
          rand3 = input("Press [ENTER] To Exit")
          replit.clear()
          status = True